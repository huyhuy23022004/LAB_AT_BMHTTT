-- 1. Tạo Database LAB1_MaHoaCoDien
IF DB_ID(N'LAB1_MaHoaCoDien') IS NULL
BEGIN
    CREATE DATABASE [LAB1_MaHoaCoDien];
END
GO

USE [LAB1_MaHoaCoDien];
GO

-- 2. Tạo bảng lưu lịch sử thao tác
IF OBJECT_ID(N'dbo.history', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.history (
        id BIGINT IDENTITY(1,1) PRIMARY KEY,
        created_at DATETIME2(0) NOT NULL DEFAULT SYSDATETIME(),
        algorithm NVARCHAR(30) NOT NULL,
        operation NVARCHAR(10) NOT NULL,
        input_text NVARCHAR(MAX) NOT NULL,
        result_text NVARCHAR(MAX) NOT NULL
    );
END
GO

-- 3. Các câu lệnh truy vấn kiểm tra dữ liệu
SELECT TOP (20) id, created_at, algorithm, operation, input_text, result_text
FROM dbo.history 
ORDER BY id DESC;
GO

SELECT COUNT(*) AS so_ban_ghi FROM dbo.history;
GO

SELECT algorithm, COUNT(*) AS so_lan 
FROM dbo.history 
GROUP BY algorithm 
ORDER BY so_lan DESC;
GO